﻿// Copyright lurongjiu 2025 All Rights Reserved.

#pragma once

class ISlateStyle;

class FMigrateActorsIconStyle
{
public:

	static void InitializeIcons(); 

	static void ShutDownIcons();

	static const ISlateStyle& Get();

	static FName GetStyleSetName();

private:
	
	static TSharedRef<FSlateStyleSet> CreateSlateStyleSet();
	
	static TSharedPtr<FSlateStyleSet> CreatedSlateStyleSet;
};