﻿// Copyright lurongjiu 2025 All Rights Reserved.

#pragma once

/*Debug functions*/
#if 1
#include "Kismet/KismetStringLibrary.h"

namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message);
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%i"),message);
	}
	static void Print(const double& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, UKismetStringLibrary::Conv_DoubleToString(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%f"),message);
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message.ToString());
	}
	static void Print(const FVector& InVector, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InVector.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InVector.ToString());
	}
	static void Print(const FRotator& InRotator, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InRotator.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InRotator.ToString());
	}
	static void Print(const FLinearColor& InColor, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InColor.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InColor.ToString());
	}
	static void Print(const FVector3f& InVector, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InVector.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InVector.ToString());
	}
	static void FastPrint()
	{
		Print(TEXT("FastPrint : Debug"));
		UE_LOG(LogTemp,Warning,TEXT("FastPrint : Debug"));
	}
}
#endif

#define BETA 0

struct FMigrationOptions;
struct FActorTreeItem;

namespace MigrateActorUtils
{
	bool IsActorInTempMap(const AActor* Actor);

	bool IsActorInTempMap(const FActorTreeItem* SelectedActor);

	bool MigrateExternalActors(const TArray<FName>& PackageNamesToMigrate, FString& DestinationPath);

	bool OpenSelectFolderDialog(FString& OutFolderName, const FString& Title);

	bool MigrateMoveFile(const TArray<FName>& PackageNamesToMigrate, const FString& DestinationPath);
	
	void GetActorsReferencedAssets(TArray<FName>& AssetsList, TWeakObjectPtr<AActor> Actor);

	void AddActorsLocatedFoldersToList(TArray<FName>& PackageNamesList,TWeakObjectPtr<AActor> Actor);

#if BETA

	void SynFromContentWhenLevelClosed(const FString& LevelAssetPackageName);
#endif

	void ToggleRecorderState();

	bool GetRecorderState();

	void ClearLevelDeletedActorsList();

	void DeletedActorAddToList(const AActor* ActorDeleted);
	
	bool DeletedActorListAddToJson();

	//for different version
	EAppReturnType::Type OpenMessageDialog(EAppMsgType::Type MessageType, const FText& Message, const FText& OptTitle);

	FName GetActorFolderPackageName(TWeakObjectPtr<AActor> Actor, FFolder ActorFolder);
}
